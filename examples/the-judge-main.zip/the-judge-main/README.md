# The Judge

This repo is a collection of notebooks for the 'The Judge' video series

### 1. Build and evaluate an agent

<img src="./build-eval-agent/images/architecture.png" alt="architecture" width="1250">

### 2. Evaluate document extraction

<img src="./evaluate-document-extraction/extraction-eval.png" alt="architecture" width="1250">
