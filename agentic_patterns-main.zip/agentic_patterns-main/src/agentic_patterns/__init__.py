from .reflection_pattern import ReflectionAgent
